# Automate Your Life with Python
This repository contains scripts of my course "Automate Your Life with Python": https://www.udemy.com/course/automate-your-life-with-python/?referralCode=7FA8B361D7A92B03A8C3

